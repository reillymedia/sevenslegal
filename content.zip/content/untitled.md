---
title: 'Contact Us Page'
url: '/?post_type=wpcf7_contact_form&p=85'
date: Mon, 08 Dec 2014 21:50:10 +0000
draft: false
---

\[text\* your-name akismet:author placeholder "Name"\]

\[email\* your-email akismet:author\_email placeholder "Email"\]

\[text phone placeholder "Phone No."\]

\[textarea your-message 6x42 placeholder "Message"\]

\[submit "Send"\]

1 Message Sevens Legal Contact Form info@sevenslegal.com scott@reillymedia.com, stan@sevenslegal.com, monica@sevenslegal.com, Kerry@sevenslegal.com From: \[your-name\] <\[your-email\]> Phone No: \[phone\] Message Body: \[your-message\] -- This e-mail was sent from a contact form on Sevens Legal (https://www.sevenslegal.com) Reply-To: \[your-email\] Your message was sent successfully. Thanks. Failed to send your message. Please try later or contact the administrator by another method. Validation errors occurred. Please confirm the fields and submit it again. Failed to send your message. Please try later or contact the administrator by another method. Please accept the terms to proceed. Please fill the required field. This input is too long. This input is too short. Failed to upload file. This file type is not allowed. This file is too large. Failed to upload file. Error occurred. Date format seems invalid. This date is too early. This date is too late. Number format seems invalid. This number is too small. This number is too large. Your answer is not correct. Email address seems invalid. URL seems invalid. Telephone number seems invalid.