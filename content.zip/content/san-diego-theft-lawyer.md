---
title: 'San Diego Theft Lawyer'
url: '/san-diego-theft-lawyer/'
date: Fri, 04 Mar 2011 08:11:53 +0000
draft: false
---

![San Diego Theft Lawyer](https://www.sevenslegal.com/wp-content/uploads/2014/12/Samantha-Greene-2-200x300.jpg)San Diego Theft Lawyer
-------------------------------------------------------------------------------------------------------------------------------------

If charged with a theft crime you can face severe criminal penalties and social stigma. The attorneys at Sevens Legal, APC are here to fight for your rights and restore your reputation. Our attorneys have years of experience and knowledge to obtain a result in your favor, no matter the severity of the charges you may be facing.

**Common Types of Theft Offenses:**

*   Petty Theft
    *   Property valued at $950.00 or less
    *   Not taken from the person of another
*   Grand Theft
    *   Property valued at $950.00 or more
    *   Taken from the person of another
    *   Of an automobile or firearm
*   Burglary
    *   Entering the property of another with the intent to commit a felony.
*   Robbery
    *   Taking the personal property in the possession of another, from his or her possession with the use of force or fear.
*   Identity Theft
    *   Taking personal information and using it for an unlawful purpose
*   Receiving or Possession of Stolen Property
    *   Knowingly buying, receiving, selling or concealing property that has been stolen from another person

No matter the type of theft crime, the punishment is severe. Theft crimes can be classified as a misdemeanor or felony.  Fines, jail and/or prison time are often standard punishment.  Individuals may also be subject to civil liability if the alleged theft is from a retailer.

**Defenses to Theft Crimes**
----------------------------

If you are facing theft charges in California, there are a number of defenses that can be employed to your advantage. Most notably, we will work to demonstrate that you did not have the requisite intent to steal any property and you had a good faith belief that the property was yours to possess. Of course, all circumstances must be reviewed when faced with theft charges but we believe in you and your day in court.

Contact a San Diego Theft Lawyer
--------------------------------

Call our experienced attorneys to fight for your rights. We are available and can provide you with the defense you deserve. Call now 619-297-2800.