---
title: 'Samantha Featured in Attorney Journal'
url: '/awards/samantha-greene-featured-attorney-journal/502/'
date: Wed, 25 May 2016 18:27:50 +0000
draft: false
categories: ['Awards']
---

