---
title: 'Alex Fuqua Obtains Not Guilty Verdict in Attempted Murder Trial'
url: '/criminal-attorney/alex-fuqua-obtains-not-guilty-verdict-attempted-murder-trial/800/'
date: Mon, 09 Apr 2018 19:06:00 +0000
draft: false
categories: ['Criminal Law']
---

Alex Fuqua Obtains Not Guilty Verdict in Attempted Murder Trial
---------------------------------------------------------------