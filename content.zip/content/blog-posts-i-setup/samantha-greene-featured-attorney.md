---
title: 'Samantha Greene Featured in Attorney Journal'
url: '/awards/samantha-greene-featured-attorney/510/'
date: Fri, 17 Jun 2016 09:15:16 +0000
draft: false
categories: ['Awards']
---

