---
title: 'San Diego Rape Lawyer'
url: '/san-diego-rape-lawyer/'
date: Wed, 28 Apr 2010 16:30:41 +0000
draft: false
---

[![San Diego Rape Lawyer](https://www.sevenslegal.com/wp-content/uploads/2014/12/Samantha-Greene-2-200x300.jpg)](https://www.sevenslegal.com/wp-content/uploads/2014/12/Samantha-Greene-2.jpg)San Diego Rape Lawyer
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

### What is Rape? Penal Code Section 261 PC

When they hear the term rape, many people create a mental image of an assault committed by means of violent physical force. The reality is, however, that rape is any non-consensual sexual activity, including those accomplished without physical means, using such methods as drugs or guile. Any form of sexual conduct forced on a person against their will through means of violence, menace, duress, fear of injury, or other danger is rape under California law.

There are a number of statutes in California that pertain to rape, all of which are among the most serious of criminal offenses with which an individual can be charged.

The most common type of rape (Penal Code Section 261 PC) is defined as criminal offense that involves nonconsensual sexual intercourse by means of threats, force, or fraud.  At its core, this form of rape involves vaginal or anal penetration that includes force by instrumentation on someone, conscious or unconscious, or on any victim unable to consent.

Date Rape
---------

Date rape charges are also filed under Penal Code Section 261 PC. Cases of this nature can sometimes be highly contested between the victim and the accused with the difference between a conviction and an acquittal depending on who the jury believes. The question of if sex took place is often not questioned, but rather was the sex consensual or not? Most of these cases do not involve force or injury to the victim. Often, they are cases of "he said, she said" with the defendant having the greatest stake in the outcome.

Other Forms of Rape
-------------------

### Penal Code 262 PC "Spousal Rape."

### Penal Code 261.5 PC "Statutory Rape."

Other forms of rape warrant their own specific statutes in state law. Examples include:

*   \- Penal Code 262 PC "Spousal Rape." Anyone who has intercourse with their spouse without their consent and does so with force or threat, and for sexual pleasure or arousal, is guilty of violating California Penal Code 262.
*   \- Penal Code 261.5 PC "Statutory Rape." Anyone who knowingly has intercourse with a minor can be found guilty of Statutory Rape. A minor is defined as anyone under the age of 18.

Penalties for Rape
------------------

Rape is one of the most serious criminal charges that a defendant may face. A case may be highly complex because of circumstances that are difficult to explain and understand. The penalties for these offenses are harsh and conviction includes lifetime sex offender registration.

### [Contact a San Diego Rape Lawyer](#contact)

Because mere accusations of rape can shatter personal reputations, destroy families, and take away freedoms, it is important that anyone who faces the prospect of rape charges immediately obtain the services of a qualified attorney experienced in sex crime defense. To protect your rights during the investigation and start building an effective defense, you need the aggressive representation provided by Sevens Legal, APC. Contact Sevens Legal, APC, today for a free consultation.