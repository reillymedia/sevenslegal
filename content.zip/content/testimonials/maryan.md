---
title: 'Maryan'
url: '/testimonial/maryan/'
date: Tue, 09 Dec 2014 10:30:53 +0000
draft: false
---

The way samantha handled my case was a mazing. She is knowledgeable person keeps me updated. Also offered me options, I definitely recommend anyone who needs legal help. Thank u Samantha Green.