---
title: 'Cammy T.'
url: '/testimonial/cammy/'
date: Tue, 22 Mar 2016 18:51:33 +0000
draft: false
---

If you are ever caught in a legal situation and you need good representation, I highly recommend Sevens Legal. They are caring, knowledgeable, honest and work tirelessly to help you with your case. I am truly thankful for all of the work and legal advice they gave me during a time when I needed it the most. They took care of everything and I felt safe in their hands. It really helps to have an excellent legal team and you can't go wrong with Sevens Legal.