---
title: 'Shade Williams'
url: '/testimonial/shade-williams/'
date: Tue, 22 Mar 2016 18:52:02 +0000
draft: false
---

Where do I begin....Samantha and her team are professionals with a wealth of knowledge and expertise second to none. Recently, a loved one was involved in an unfortunate legal situation and Samantha was there to provide an outcome that was swift and favorable. She truly understood the situation and was very professional and studious. Our family was going through a rebuilding stage and she prevented any further delays. Our family owes a lot to Samantha and her team. She is a special person to us and we would not be okay with not sharing with persons in need of the quality of the Sevens Legal Team.