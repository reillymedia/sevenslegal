---
title: 'Kaytee Allen'
url: '/testimonial/kaytee-allen'
date: Tue, 22 Mar 2016 18:53:56 +0000
draft: false
---

Sevens legal of San Diego is one of the best criminal defense law firms! My friend had used their legal services and recommend I contacted them. I was extremely happy with the process. Props to Stan Mann and Samantha Greene and Michele Bos! My questions were answered clearly and they did not surprise me with any fees or anything. I have so much to be thankful for. Thanx for all of the help and encouragement!