---
title: 'Alejandro Amigo'
url: '/testimonial/alejandro-amigo/'
date: Tue, 22 Mar 2016 18:53:24 +0000
draft: false
---

I've been working as an investigator and paralegal for approximately 29 years and have worked with multiple law firms in San Diego county. Sevens Legal truly cares and aggressively represents their clients to get the best results possible. People looking for a criminal defense attorney should call Sevens Legal and they too will be happy they hired the firm.