---
title: 'Client'
url: '/testimonial/client-2/'
date: Tue, 09 Dec 2014 10:32:13 +0000
draft: false
---

Samantha Greene handled my felony domestic violence case so professionally I felt at ease from the moment I met with her and her staff. The results were more than I could have hoped for. She was responsive to my many calls and met with me multiple times to go over my case and answer all my questions and most importantly put my mind at ease through the entire case. I hope never to have to use a criminal defense attorney again, but if I do, Samantha will be my only choice . Thank you Samantha for your caring and professionalism.