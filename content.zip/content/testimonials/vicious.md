---
title: 'Vicious V'
url: '/testimonial/vicious/'
date: Tue, 22 Mar 2016 18:59:20 +0000
draft: false
---

Samantha Green was great handling my case. She got me from a misdemeanor to a fraction. Im happy with that. She also kept me updated on my case and i never had to call her for an update. I would definitely use her again and recommend her to people.