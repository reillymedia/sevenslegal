---
title: 'James H'
url: '/testimonial/james/'
date: Tue, 22 Mar 2016 18:53:04 +0000
draft: false
---

I highly recommend Sevens Legal and their team if you have any legal problems and need help. Samantha was awesome and I would suggest them to any of my friends and even my family. Everything went so smooth and I got exactly what I was looking for with with my case results. Please consider them if you're looking for a some of the best attorneys in San Diego.