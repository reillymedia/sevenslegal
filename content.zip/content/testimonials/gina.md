---
title: 'Gina L'
url: '/testimonial/gina/'
date: Tue, 22 Mar 2016 18:58:46 +0000
draft: false
---

Never in my life did I envision myself needing the services of an Attorney, so having to confront not only my legal situation but also needing to select someone I didn't know and to trust them with my freedom was an overwhelming task. After researching and talking to several San Diego attorneys, my wife and I made the decision to entrust my case to Samantha Greene and the Sevens Legal staff. I was made to feel welcomed and quickly put at ease. The first conversation with Stan set me at ease and the first meeting with Samantha sealed it for us. I am more than satisfied with the outcome of my case and appreciated being made to feel that I was not alone - Thank You Samantha and Sevens Legal.