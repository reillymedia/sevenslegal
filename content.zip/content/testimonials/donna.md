---
title: 'Donna'
url: '/testimonial/donna/'
date: Tue, 09 Dec 2014 10:32:53 +0000
draft: false
---

Samantha Green recently helped me with a legal problem and I highly recommend her to anyone in need of attorney services. She is professional and will take steps to defend your rights immediately. I have great respect for Samantha and her colleagues and appreciate the prompt and professional legal services they provided me.