---
title: 'Nick C'
url: '/testimonial/nick/'
date: Tue, 22 Mar 2016 18:57:16 +0000
draft: false
---

Samantha was a great lawyer. She had 15 felony charges dropped and my interstate compact approved so I could return home to NYC. Friendly and professional, was there with me every step of the way. Highly recommend her~