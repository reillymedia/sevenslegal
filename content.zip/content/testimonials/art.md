---
title: 'Art Y'
url: '/testimonial/art/'
date: Tue, 22 Mar 2016 18:54:42 +0000
draft: false
---

Sevens legal is a pleasure to work with. They are consummate professionals, knowledgeable, and friendly. Michelle Bos has an extremely high level of expertise and a refreshing demeanor. Stan Man is extremely helpful and prides himself on being available to deliver a high level of service. They both take the time to listen and provide excellent service.