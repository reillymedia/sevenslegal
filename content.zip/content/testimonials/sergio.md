---
title: 'Sergio D'
url: '/testimonial/sergio/'
date: Tue, 22 Mar 2016 18:58:17 +0000
draft: false
---

Samantha Greene and all the partners at Sevens Legal APC are five star attorneys. After retaining Ms.Greene she fought my case aggressively as well as having multiple traffic infractions completely dismissed. Samantha isn't just an attorney she is the BEST in San Diego if not the entire country. She didn't receive attorney of the year for no reason, it's because she is compassionate with her clients and will not stop until your case is won or severely reduced. Don't waste anymore time if your looking for another attorney, Samantha Greene of Sevens Legal APC will NOT let you down. I would not be surprised if she becomes one of the top in the country, her work speaks for itself and I highly endorse and recommend Samantha Greene Attorney at Law