---
title: 'Amanda K'
url: '/testimonial/amanda/'
date: Tue, 22 Mar 2016 18:59:40 +0000
draft: false
---

HANDS DOWN Samantha Greene is the BEST legal defense attorney in San Diego! She is soooo knowledgeable, intelligent, caring, professional and such an amazing woman inside and out!! Sevens Legal ,APC went above and beyond to help my fiance out when he got into trouble with probation. Samantha and Stan Mann were there to answer every one of my questions(anytime of day) and had me at ease knowing we had the best attorney representing us in court. They are both such extraordinary, amazing individuals i will recommend them to everyone and anyone in need of legal help!! To top off this amazing review, of course Samantha was so professional and did such an amazing job in court, we received the best results possible!!!! My fiance was released!!!!! If ANYONE in San Diego is looking for an excellent legal attorney, I recommend and give 100% satisfactory to Samantha Greene and her entire team!! Thank you again from the bottom of my heart for not only doing everything you could to help us out but treated us like family!!! You guys ROCK :) :0 :)