---
title: 'Client'
url: '/testimonial/client/'
date: Tue, 09 Dec 2014 10:26:15 +0000
draft: false
---

Attorney Samantha Greene and her Partner, “Stan The Man” were both thorough in their client intake and representation. I contacted Samantha’s office after researching online for a good defense attorney. I was seeking legal counsel for a court case in San Diego and needed to feel comfortable that I had good representation with much experience and expertise relating to my situation. I originally spoke with “Stan The Man”, who completed my client intake process. He made me feel as though I had known he and Attorney Greene my entire life. After explaining details of my circumstances, he informed me of the attorney fees required for my defense, which were very reasonable, given my circumstances.

I then met with Samantha shortly prior to my first court appearance to discuss my case. I was kept informed throughout the entire process and was please with the outcome. Had I not obtained expert, competent, experienced legal representation, the outcome of my situation would most definitely been different.

I would definitely recommend Attorney Samantha Ashley Greene as excellent legal representation.