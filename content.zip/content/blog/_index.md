---
title: 'Sevens Legal Blog'
date: Thu, 13 Apr 2017 15:00:57 +0000
draft: false

---