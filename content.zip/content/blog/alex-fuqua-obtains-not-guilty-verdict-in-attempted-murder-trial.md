+++
categories = "Criminal Law"
date = 2022-11-13T18:30:00Z
pfd_file = "/img/wellington-verdict-form_-count1_redacted.pdf"
summary = "Alex Fuqua Obtains Not Guilty Verdict in Attempted Murder Trial"
tags = []
title = "Alex Fuqua Obtains Not Guilty Verdict in Attempted Murder Trial"
url = "/criminal law/alex-fuqua-obtains-not-guilty-verdict-attempted-murder-trial/"

+++
