+++
categories = " Burglary"
date = 2022-11-13T18:30:00Z
pfd_file = ""
summary = "When most people think of theft, they think of shoplifting clothes or jewelry, or perhaps robbery, burglary, assault, or fraud. When animals are stolen, chances are they are a high-priced dog from a pet store or breeder. But a lemur? Lemur Ransomed After Theft Julie Harris, the owner of Gizmo the lemur, was burglarized by "
tags = ["Blog", "Criminal Law", "Theft"]
title = "Theft of Lemur Not a Bad Disney Movie"
url = "/burglary/theft-lemur-bad-disney-movie/"

+++
When most people think of [theft](https://www.sevenslegal.com/san-diego-theft-lawyer/ "San Diego Theft Lawyer"), they think of shoplifting clothes or jewelry, or perhaps robbery, burglary, assault, or fraud. When animals are stolen, chances are they are a high-priced dog from a pet store or breeder. But a lemur?

## Theft of Lemur Not a Bad Disney Movie

When most people think of [theft](https://www.sevenslegal.com/san-diego-theft-lawyer/ "San Diego Theft Lawyer"), they think of shoplifting clothes or jewelry, or perhaps robbery, burglary, assault, or fraud. When animals are stolen, chances are they are a high-priced dog from a pet store or breeder. But a lemur?

## Lemur Ransomed After Theft

Julie Harris, the owner of Gizmo the lemur, was burglarized by James Edward Welborn, Jr. In addition to Gizmo, Welborn also took her TV. Gizmo the lemur, a small mammal, was valued at approximately $1,500. According to Detective Ben Brown, the whole event was “kind of like a bad Disney movie.”

### Sister Suspicious After Lemur Theft

After Welborn, the alleged thief, burglarized Harris’ home, he took the little guy to his sister’s house, telling her he found it. After seeing a local news report about the theft of Gizmo, she started doubting her brother’s story, especially since the picture of Gizmo matched the lemur she was taking care of. After telling her brother about the cash bounty on the head of the little fellow, she told him to come take him away.

### Ransom Demanded After Lemur Theft

The [lemur theft](https://www.sevenslegal.com/san-diego-theft-lawyer/ "San Diego Theft Lawyer") got more complicated when Welborn and his friend Brian Sanders decided to ransom Gizmo for the reward money. Sanders contacted Harris and arranged to meet in a gas station. When she got there, Gizmo wasn’t with them, but his picture was on his computer. Sanders confessed everything to the police, who then was able to figure things out and got Gizmo and his owner, Harris, back together.

### Traffic Violation Nabs Thief in Lemur Theft

Welborn was able to elude police officers for a bit, but his luck ran out when he was stopped for a traffic violation. When his identity was processed through the local information system, the police connected him to the burglary and [theft](https://www.sevenslegal.com/san-diego-theft-lawyer/ "San Diego Theft Lawyer") of the TV and little Gizmo the lemur.

Detective Brown wrapped up the unusual case by telling reporters, “\[T\]o take the monkey to his sister, cross state lines and get somebody else to contact the family…and try to get the reward money … this is hands down the oddest, funniest case I have ever worked.”

Unlike the theft of Gizmo the lemur, [theft](https://www.sevenslegal.com/san-diego-theft-lawyer/ "San Diego Theft Lawyer") cases aren’t this amusing.

If you have been allegedly accused of [theft](https://www.sevenslegal.com/san-diego-theft-lawyer/ "San Diego Theft Lawyer"), you must realize this is a serious charge with far-reaching consequences. You need to contact a criminal defense attorney experienced in theft cases who can build a good defense for you such as Sevens Legal, APC. Contact [Sevens Legal, APC](https://www.sevenslegal.com/ "Sevens Legal, APC"), today for a free consultation.

[Sevens Legal, APC](https://www.sevenslegal.com/ "Sevens Legal, APC")

Criminal Defense Attorneys

3555 4th Ave.

San Diego, CA 92103

Phone: (619) 430-2355