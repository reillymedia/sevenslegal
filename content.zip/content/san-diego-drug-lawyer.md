---
title: 'San Diego Drug Lawyer'
url: '/san-diego-drug-lawyer/'
date: Wed, 04 May 2011 07:10:55 +0000
draft: false
---

[![San Diego Drug Lawyer](https://www.sevenslegal.com/wp-content/uploads/2014/12/Samantha-Greene-2-200x300.jpg)](https://www.sevenslegal.com/wp-content/uploads/2014/12/Samantha-Greene-2.jpg)San Diego Drug Charge Lawyer
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Being convicted of any drug crime is a serious matter. Most drug charges can carry heavy convictions, fines and stay on your personal record, which can affect your job, buying a home or getting a loan. If you are convicted for any drug related crime, it is in your best interest to seek a criminal defense attorney and never accept any deal without speaking to an attorney first. Drug charges range from minor possession to a more serious charge of drug manufacturing, whatever the charges are, know that you can find guidance with your case. Choosing a great criminal defense attorney will help your case and often reduce charges. The experience and knowledge needed to deal with a drug charge can be found at Seven’s Legal. Sevens Legal is well versed in a variety of drug charges that you may be convicted of and their experience is endless. At Sevens Legal you will find a successful team that is passionate about representing their clients. If you find yourself charged with any drug crime, it is imperative that you seek a knowledgeable criminal defense attorney that will guide you through the legal system and help with reducing your charges.

Find help with Drug Charges at Sevens Legal
-------------------------------------------

Drug charges can stem from minor to more serious offences and at Sevens legal you can find a Criminal Defense Attorney for a number of drug related crimes. Regardless of the drug related crime, choosing Sevens Legal will help with protecting your rights and freedom and lead towards a positive outcome.  

*   Simple possession and possession for sale or distribution
*   DUI involving drug possession
*   Heroin manufacturing
*   Money Laundering
*   Cultivation of Marijuana
*   Drug Trafficking or smuggling
*   Juvenile or student drug offenses
*   Unauthorized possession or sale of prescription drugs

[Need Drug Possession Lawyer in Phoenix, AZ?](http://www.criminaldefenselawyers.me/phoenix-drug-crimes/phoenix-drug-possession-lawyer/) [Need a Drug Possession Lawyer in Los Angeles?](http://www.danielperlmanlaw.com/drug-crimes.shtml)

Heath & Safety Codes you may be charged with:
---------------------------------------------

 

*   Health & Safety Code 11550 HS “Under the Influence of a Controlled Substance”

 

*   Health & Safety Code 11379.6 HS “Manufacturing Drugs and Narcotics”

 

*   Health & Safety Code 11377 HS “Possession of Methamphetamine”

 

*   Health & Safety Code 11352 HS “Sale or Transportation of a Controlled Substance”

 

*   Health & Safety Code 11351 HS “Possession for Sale of Narcotics”

 

*   Health & Safety Code 11350 HS “Possession of a Controlled Substance”

DUI of Marijuana
----------------

Driving under the influence of marijuana is a crime in California under Vehicle Code 23152(e) VC. It is similar to driving under the influence of alcohol under vehicle code 23152 (a) VC. Unlike with alcohol, however, the law does not specify that any particular amount of THC in the bloodstream automatically establishes impairment. This can make the crime difficult to prove. For you to be found guilty of DUI marijuana, the prosecutor must prove that:

*   You drove a motor vehicle
*   Under the influence of marijuana
*   Because of the marijuana, your mental abilities were so impaired that you were unable to drive with the caution of a sober person, using ordinary care, under similar circumstances.

*   The penalties for DUI of marijuana are the same as the California DUI penalties involving alcohol.

 

Experience that matters
-----------------------

At sevens legal you will find a knowledgeable group of attorneys that will help with any drug related charge(s) you may be facing. Sevens Legal has decades of experience in criminal defense and great criminal defense attorneys that will support you through the technical aspects of law and offer guidance regarding your case.  If you find yourself in a position where you have been charged with a drug related crime, please call Sevens Legal for a free consultation and allow us to begin working on your behalf.