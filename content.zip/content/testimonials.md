

Samantha Green recently helped me with a legal problem and I highly recommend her to anyone in need of attorney services. She is professional and will take steps to defend your rights immediately. I have great respect for Samantha and her colleagues and appreciate the prompt and professional legal services they provided me.

**\- Donna**

\-----------------------------------------------------------------------------------------------------------------------------

  Samantha Greene handled my felony domestic violence case so professionally I felt at ease from the moment I met with her and her staff. The results were more than I could have hoped for. She was responsive to my many calls and met with me multiple times to go over my case and answer all my questions and most importantly put my mind at ease through the entire case. I hope never to have to use a criminal defense attorney again, but if I do, Samantha will be my only choice . Thank you Samantha for your caring and professionalism. **\- Client**

\-----------------------------------------------------------------------------------------------------------------------------

  Very outgoing .Samantha was on top of my case all the wayshe was able to get me the best possible results . I didn’t even have to appear .highly recommended. Professional friendly and knowledgable **\- Don**

\-----------------------------------------------------------------------------------------------------------------------------

  The way samantha handled my case was a mazing. She is knowledgeable person keeps me updated. Also offered me options, I definitely recommend anyone who needs legal help. Thank u Samantha Green. **\- Maryan**

\-----------------------------------------------------------------------------------------------------------------------------

  Attorney Samantha Greene and her Partner, “Stan The Man” were both thorough in their client intake and representation. I contacted Samantha’s office after researching online for a good defense attorney. I was seeking legal counsel for a court case in San Diego and needed to feel comfortable that I had good representation with much experience and expertise relating to my situation. I originally spoke with “Stan The Man”, who completed my client intake process. He made me feel as though I had known he and Attorney Greene my entire life. After explaining details of my circumstances, he informed me of the attorney fees required for my defense, which were very reasonable, given my circumstances. I then met with Samantha shortly prior to my first court appearance to discuss my case. I was kept informed throughout the entire process and was please with the outcome. Had I not obtained expert, competent, experienced legal representation, the outcome of my situation would most definitely been different. I would definitely recommend Attorney Samantha Ashley Greene as excellent legal representation. **\- Client**

\-----------------------------------------------------------------------------------------------------------------------------

  I got the best service from Samantha. She was really quick with solving my case. She was always available to answer my questions.

**\- Jennifer**

fbq('track', 'ViewContent', { value: 3.50, currency: 'USD' });