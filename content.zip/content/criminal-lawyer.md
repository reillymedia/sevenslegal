---
title: 'Practice Areas'
url: '/criminal-lawyer/'
date: Thu, 04 Dec 2014 05:00:06 +0000
draft: false
---

