---
title: 'Contact form 1'
url: '/?post_type=wpcf7_contact_form&p=32'
date: Sat, 06 Dec 2014 15:02:50 +0000
draft: false
---

\[text\* your-name class:form-control placeholder "Your Name"\]

\[text\* phone class:form-control placeholder "Your Phone"\]

\[email\* your-email class:form-control placeholder "Your Email"\]

\[textarea describeyourcase x5 class:form-control placeholder "describe your case"\]

\[submit class:btn class:btn-primary "Submit"\]

1 Request a free consultation info@sevenslegal.com scott@reillymedia.com, stan@sevenslegal.com, monica@sevenslegal.com, Kerry@sevenslegal.com From: \[your-name\] Email Address: \[your-email\] Phone No: \[phone\] Message: \[describeyourcase\] -- This e-mail was sent from a contact form on Sevens Legal (https://www.sevenslegal.com) Your message was sent successfully. Thanks. Failed to send your message. Please try later or contact the administrator by another method. Validation errors occurred. Please confirm the fields and submit it again. Failed to send your message. Please try later or contact the administrator by another method. Please accept the terms to proceed. Please fill the required field. This input is too long. This input is too short. Failed to upload file. This file type is not allowed. This file is too large. Failed to upload file. Error occurred. Date format seems invalid. This date is too early. This date is too late. Number format seems invalid. This number is too small. This number is too large. Your answer is not correct. Email address seems invalid. URL seems invalid. Telephone number seems invalid.